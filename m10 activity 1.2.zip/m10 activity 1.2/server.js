const express = require("express");
const dotenv = require("dotenv");
const cookieParser = require("cookie-parser");

dotenv.config();

const app = express();
app.use(express.json());
app.use(cookieParser());

const authRoutes = require("./routes/auth");
const protectedRoutes = require("./routes/protected");

app.use("/api", authRoutes);
app.use("/api", protectedRoutes);

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
