const express = require("express");
const authenticateToken = require("../middleware/authMiddleware");

const router = express.Router();

router.get("/protected", authenticateToken, (req, res) => {
  res.json({ message: "You accessed a protected route!", user: req.user });
});

router.get("/get-user", authenticateToken, (req, res) => {
  res.json({ user: req.user });
});

module.exports = router;
